#ifndef UART_H
#define UART_H
#include <stdint.h>
#include "stm32f0xx_hal.h"

#define UART_BUFFER_LEN 127

void UART_Init(UART_HandleTypeDef *huart);
void UART_ProcessCommand(const char *cmd);
void UART_SendString(const char *str);
void UART_SendChar(char c);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);

#endif
