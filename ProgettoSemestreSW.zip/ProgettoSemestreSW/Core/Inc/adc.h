/*
 * adc.h
 *
 *  Created on: May 20, 2025
 *      Author: mirza
 */

#ifndef INC_ADC_H_
#define INC_ADC_H_



#endif /* INC_ADC_H_ */
