#ifndef INC_SPI_H_
#define INC_SPI_H_

#include <stdint.h>
#include "stm32f0xx_hal.h"

extern SPI_HandleTypeDef hspi1;

void SPI_Init();
float TMP126_ReadTemperature(void);
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi);


#endif /* INC_SPI_H_ */
