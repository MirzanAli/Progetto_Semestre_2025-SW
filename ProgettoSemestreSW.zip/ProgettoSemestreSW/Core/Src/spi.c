#include "spi.h"
#include "main.h"
#include <string.h>
#include <stdio.h>

SPI_HandleTypeDef hspi1;
uint8_t buffer;

void SPI_Init(){
    __HAL_RCC_SPI1_CLK_ENABLE();
    HAL_SPI_Init(&hspi1);

}

float TMP126_ReadTemperature(void) {
    uint8_t tx[2] = {0x00, 0x00};  // comando di lettura (registro 0x00)
    uint8_t rx[2] = {0};

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET); // CS low
    HAL_SPI_TransmitReceive(&hspi1, tx, rx, 2, 1);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);   // CS high

    uint16_t raw = (rx[0] << 8) | rx[1];
    float temp = (raw >> 2) * 0.03125f;

    return temp;
}

void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi) {
    if (hspi->Instance == SPI1) {
        // Ricezione completata
    }
}
