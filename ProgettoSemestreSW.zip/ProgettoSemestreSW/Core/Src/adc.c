/*
 * adc.c
 *
 *  Created on: May 20, 2025
 *      Author: mirza
 */


