#include "uart.h"
#include "main.h"
#include "spi.h"
#include <string.h>
#include <stdio.h>

UART_HandleTypeDef huart1;

static UART_HandleTypeDef *huart_local;
static char rx_buffer[UART_BUFFER_LEN];
static uint8_t rx_index = 0;
static char rx_char;

void UART_Init(UART_HandleTypeDef *huart) {
    huart_local = huart;
    HAL_UART_Receive_IT(huart_local, (uint8_t *)&rx_char, 1);
}

void UART_ProcessCommand(const char *cmd) {
    char msg[127];

    if (strcmp(cmd, "hello") == 0) {
        snprintf(msg, sizeof(msg), "Hi!\r\n");

    } else if (strcmp(cmd, "ping") == 0) {
        snprintf(msg, sizeof(msg), "pong\r\n");

    } else if (strcmp(cmd, "redLED_on") == 0) {
    	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
        snprintf(msg, sizeof(msg), "redLED : on\r\n");

    } else if (strcmp(cmd, "redLED_off") == 0) {
    	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
        snprintf(msg, sizeof(msg), "redLED : off\r\n");

    } else if (strcmp(cmd, "greenLED_on") == 0) {
    	HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
        snprintf(msg, sizeof(msg), "greenLED : on\r\n");

    } else if (strcmp(cmd, "greenLED_off") == 0) {
    	HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
    	snprintf(msg, sizeof(msg), "greenLED : off\r\n");

    } else if (strcmp(cmd, "yellowLED_on") == 0) {
    	HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_SET);
        snprintf(msg, sizeof(msg), "yellowLED : on\r\n");

    } else if (strcmp(cmd, "yellowLED_off") == 0) {
    	HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET);
        snprintf(msg, sizeof(msg), "yellowLED : off\r\n");

    } else if (strcmp(cmd, "toggleLEDs") == 0) {
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_6);
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_7);
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_8);
        snprintf(msg, sizeof(msg), "LEDs toggled\r\n");

    } else if (strcmp(cmd, "readADC") == 0) {
        uint16_t value = 25; // Da implementare
        snprintf(msg, sizeof(msg), "AnalogSensor Temp value = %u\r\n", value);

    } else if (strcmp(cmd, "readSPI_TMP") == 0) {
        float temp = TMP126_ReadTemperature();
        snprintf(msg, sizeof(msg), "DigitalSensor Temp value = %.2f°C\r\n", temp);
        HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }
    else if (strcmp(cmd, "readI2C") == 0) {
        snprintf(msg, sizeof(msg), "TBD = \r\n");

    } else {
        snprintf(msg, sizeof(msg), "Unknown command: %s\r\n", cmd);
    }

    HAL_UART_Transmit(huart_local, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
}

void UART_SendString(const char *str) {
    HAL_UART_Transmit(huart_local, (uint8_t *)str, strlen(str), HAL_MAX_DELAY);
}

void UART_SendChar(char c) {
    HAL_UART_Transmit(huart_local, (uint8_t *)&c, 1, HAL_MAX_DELAY);
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == huart_local->Instance) {
        if (rx_char == '\r') {
            // ignora il carriage return
        }
        else if (rx_char == '\n') {
            if (rx_index > 0) {
                rx_buffer[rx_index] = '\0';
                UART_ProcessCommand(rx_buffer);
                rx_index = 0;
            }
        }
        else {
            if (rx_index < UART_BUFFER_LEN - 1) {
                rx_buffer[rx_index++] = rx_char;
            }
        }
        HAL_UART_Receive_IT(huart_local, (uint8_t *)&rx_char, 1);
    }
}

